
    import streamlit as st
    import os
    from pdfminer.high_level import extract_text
    import openai

    st.set_page_config(page_title="AI Resume Analyzer")
    st.title("🤖 AI Resume Analyzer")

    api_key = st.text_input("OpenAI API Key (or set OPENAI_API_KEY env variable)", type="password")
    if api_key:
        openai.api_key = api_key
    else:
        openai.api_key = os.getenv("OPENAI_API_KEY")

    uploaded_file = st.file_uploader("Upload your resume (PDF or .txt)", type=["pdf","txt"])
    if uploaded_file:
        file_path = os.path.join("temp_resume")
        with open(file_path, "wb") as f:
            f.write(uploaded_file.getbuffer())
        if uploaded_file.type == "application/pdf" or uploaded_file.name.lower().endswith(".pdf"):
            text = extract_text(file_path)
        else:
            text = open(file_path,"r",encoding="utf-8", errors="ignore").read()

        st.subheader("Extracted Text (preview)")
        st.code(text[:1000])

        if st.button("Analyze with OpenAI") and openai.api_key:
            prompt = f"""You are an expert career coach. Analyze the following resume text and:
1) Provide 5 concise improvement suggestions.
2) Extract a JSON list of key technical skills.
3) Suggest 5 job titles that match this resume.
Respond in JSON with keys: suggestions, skills, roles.
Resume text:
{text}
"""
            with st.spinner("Analyzing..."):
                resp = openai.ChatCompletion.create(
                    model="gpt-4o-mini",
                    messages=[{"role":"user","content":prompt}],
                    max_tokens=800,
                    temperature=0.2
                )
                ans = resp["choices"][0]["message"]["content"]
            st.subheader("OpenAI Response")
            st.write(ans)
        elif st.button("Analyze with OpenAI"):
            st.error("OpenAI API key not provided. Set OPENAI_API_KEY or paste key above.")
