# 💤 Drowsiness Detection System
**By Keerti R S | BE in Electronics and Communication | Government Engineering College Devagiri Haveri**

### 📘 Overview
A real-time computer vision system that detects driver drowsiness using the Eye Aspect Ratio (EAR) method and alerts users to prevent accidents.

### 🧰 Tech Stack
Python • OpenCV • Dlib • Scipy • Playsound

### ⚙️ Features
- Eye tracking using webcam  
- Automatic alarm sound when eyes close for too long  
- Real-time EAR value display  

### 🚀 Run Instructions
```bash
pip install -r requirements.txt
python detect_drowsiness.py
```

> 📎 Note: Download `shape_predictor_68_face_landmarks.dat` from the Dlib website and place it in your project folder.

### 🏆 Author & Links
Keerti R S | [LinkedIn](https://www.linkedin.com/in/keerti-r-s-30543b318) | [GitHub](https://github.com/Keerti-112)
