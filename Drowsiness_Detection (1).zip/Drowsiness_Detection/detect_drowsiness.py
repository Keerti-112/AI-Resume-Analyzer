
import cv2
import dlib
from scipy.spatial import distance as dist
import time
import playsound
import os

def eye_aspect_ratio(eye):
    A = dist.euclidean(eye[1], eye[5])
    B = dist.euclidean(eye[2], eye[4])
    C = dist.euclidean(eye[0], eye[3])
    ear = (A + B) / (2.0 * C)
    return ear

# Load dlib's face detector and shape predictor (add instructions in README to download)
predictor_path = "shape_predictor_68_face_landmarks.dat"
if not os.path.exists(predictor_path):
    print("Please download 'shape_predictor_68_face_landmarks.dat' and place it in the project folder.")
    print("Download from: http://dlib.net/files/shape_predictor_68_face_landmarks.dat.bz2")
    # Continue but will exit gracefully
detector = dlib.get_frontal_face_detector()
predictor = None
if os.path.exists(predictor_path):
    predictor = dlib.shape_predictor(predictor_path)

(lStart, lEnd) = (42, 48)  # right eye
(rStart, rEnd) = (36, 42)  # left eye

EYE_AR_THRESH = 0.25
EYE_AR_CONSEC_FRAMES = 20

COUNTER = 0
ALARM_ON = False

cap = cv2.VideoCapture(0)
time.sleep(1.0)

while True:
    ret, frame = cap.read()
    if not ret:
        break
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    rects = detector(gray, 0)
    for rect in rects:
        if predictor is None:
            continue
        shape = predictor(gray, rect)
        coords = []
        for i in range(36, 48):
            part = shape.part(i)
            coords.append((part.x, part.y))
        # split eyes
        leftEye = coords[0:6]
        rightEye = coords[6:12]
        leftEAR = eye_aspect_ratio(leftEye)
        rightEAR = eye_aspect_ratio(rightEye)
        ear = (leftEAR + rightEAR) / 2.0
        if ear < EYE_AR_THRESH:
            COUNTER += 1
            if COUNTER >= EYE_AR_CONSEC_FRAMES and not ALARM_ON:
                ALARM_ON = True
                print("Drowsiness detected! Alarm!")
                # play alarm if file exists
                alarm_file = "alarm.wav"
                if os.path.exists(alarm_file):
                    playsound.playsound(alarm_file)
        else:
            COUNTER = 0
            ALARM_ON = False
    cv2.putText(frame, f"EAR: {ear if 'ear' in locals() else 0:.2f}", (10,30),
                cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0,255,0),2)
    cv2.imshow("Frame", frame)
    key = cv2.waitKey(1) & 0xFF
    if key == 27:
        break
cap.release()
cv2.destroyAllWindows()
