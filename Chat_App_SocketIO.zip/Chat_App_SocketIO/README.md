# 💬 Real-Time Chat Application
**By Keerti R S | BE in Electronics and Communication | Government Engineering College Devagiri Haveri**

### 📘 Overview
A real-time web chat app using Node.js, Express and Socket.io that allows users to send messages instantly across connected clients.

### 🧰 Tech Stack
Node.js • Express.js • Socket.io • HTML • CSS

### ⚙️ Features
- Live chat between multiple users  
- Instant message updates  
- Simple responsive UI  

### 🚀 Run Instructions
```bash
npm install
npm start
```
Then open your browser at: **http://localhost:3000**

### 🏆 Author & Links
Keerti R S | [LinkedIn](https://www.linkedin.com/in/keerti-r-s-30543b318) | [GitHub](https://github.com/Keerti-112)
